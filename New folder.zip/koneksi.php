<?php
$conn=mysqli_connect("localhost","root","","elektromedik_1904005");
if ($conn) echo mysqli_error($conn);
?>