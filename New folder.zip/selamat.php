<?php
echo "Selamat datang $user_id, $user_name bagian: $user_level  di Sistem Informasi pencatatan Alat kesehaatan Prodi DIII TEKNIK elektro medik";
?>